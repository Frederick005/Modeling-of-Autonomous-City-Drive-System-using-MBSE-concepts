package org.scenariotools.smlk.examples.scil

import io.cucumber.junit.Cucumber
import io.cucumber.junit.CucumberOptions
import org.junit.runner.RunWith

@RunWith(Cucumber::class)
@CucumberOptions(
    features = ["D:\\Fh-dortmund\\2nd_semester\\Automotive Systems block week\\Kotlin_2ndAttempt\\smlk\\smlk\\src\\test\\kotlin\\org\\scenariotools\\smlk\\examples\\scil"],
    tags = ["not @ignored"],
    strict = true
)

class RunTest

