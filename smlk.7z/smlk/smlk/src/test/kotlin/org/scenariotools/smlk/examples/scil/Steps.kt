package org.scenariotools.smlk.examples.scil

import io.cucumber.java8.En
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.Assert
import org.scenariotools.smlk.*
import org.scenariotools.smlk.examples.tdss.testEventNode

val midRangeSensor = MidRangeSensor()
val vehicleControlUnit = VehicleControlUnit()
val nearRangeSensor= NearRangeSensor()
val dasyUnit= DasyUnit()
val centralGatewayUnit= CentralGatewayUnit()
val espUnit= ESPUnit()
val brakeSystem= BrakeSystem()
val cameraUnit = CameraUnit()
val vehicleMotionandPositionSensor = org.scenariotools.smlk.examples.scil.VehicleMotionandPositionSensor()
val informationDomainComputer = org.scenariotools.smlk.examples.scil.InformationDomainComputer()
val millimeterRadarSensor = org.scenariotools.smlk.examples.scil.MillimeterRadarSensor()


var specificationModel = createScenarioProgram(midRangeSensor, nearRangeSensor, cameraUnit, dasyUnit,
    centralGatewayUnit, espUnit, brakeSystem, vehicleControlUnit, vehicleMotionandPositionSensor,
    informationDomainComputer, millimeterRadarSensor)

class StepDefs: En {

    init {
        Given("^init test setup$") {
            testEventNode = EventNode()
            specificationModel = createScenarioProgram(
                midRangeSensor, nearRangeSensor, cameraUnit, dasyUnit,
                centralGatewayUnit, espUnit, brakeSystem, vehicleControlUnit, vehicleMotionandPositionSensor,
                informationDomainComputer, millimeterRadarSensor
            )


            specificationModel.terminatingEvents.add(TestDoneEvent)
            specificationModel.eventNode.registerSender(
                testEventNode,
                specificationModel.environmentMessageTypes.symbolicEvents() union TestDoneEvent
            )
            val observedTesteeEvents = ALLEVENTS excluding specificationModel.environmentMessageTypes.symbolicEvents()
            testEventNode.registerSender(specificationModel.eventNode, observedTesteeEvents excluding TestDoneEvent)

            runBlocking() {
                GlobalScope.launch {
                    specificationModel.run()
                }
            }
        }
        

        When("^the signal MidRangeSensor reads Detect Object$") {
            send(midRangeSensor.detectDistantObjects("Detect Object"))
        }
        Then("^the DASy should send a notification for distant object$") {
            receive(dasyUnit.sendNotification("Detect Object"))
        }
        Then("^the central gateway should forward the notification for distant object$") {
            receive(dasyUnit.sendNotification("Detect Object"))
            receive(centralGatewayUnit.forwardNotification("Detect Object"))
        }
        When("^the VCU forwards message for MidRangeSensor$") {
            send(vehicleControlUnit.forwardgatewaymessage(" Detect Object"))
        }
        Then("^the Brake System applies slow brake for distant object$") {
            receive(brakeSystem.slowbrake())
        }
        When("^the signal NearRangeSensor reads Detect near range Object$") {
            send(nearRangeSensor.detectSurroundingObject("Detect near range Object"))
        }
        Then("^the DASy should send a notification for surrounding object$") {
            receive(dasyUnit.sendNotification("Detect near range Object"))
        }
        Then("^the central gateway should forward the notification for surrounding object$") {
            receive(dasyUnit.sendNotification("Detect near range Object"))
            receive(centralGatewayUnit.forwardNotification("Detect near range Object"))
        }
        When("^the VCU forwards message for near range Object$") {
            send(vehicleControlUnit.forwardgatewaymessage(" Detect near range Object"))
        }
        Then("^the Brake System applies firm brake for surrounding object$") {

            receive(brakeSystem.firmbrake())
        }
        When("^The Camera unit detects Heavy rain$") {
            send(cameraUnit.detectHeavyRain("Heavy Rain"))
        }
        Then("^It sends notification to the ESP unit via DASy unit ,Central Gateway unit and vehicle control unit$") {
            receive(dasyUnit.sendNotification("Heavy Rain"))
            receive(centralGatewayUnit.forwardNotification("Heavy Rain"))
        }
        When("^The ESP unit recieves notification from Camera unit$") {
            send(vehicleControlUnit.forwardgatewaymessage("Heavy Rain"))
        }
        Then("^It manipulates the speed of the vehicle to prevent skidding$") {
            receive(espUnit.ManipulateSpeed("Prevent Skidding"))
        }
        When("^The signal cameraSense detects no moving object$") {
            send(cameraUnit.cameraSensing("Detecting non moving Objects"))
        }
        And("^Also the signal motionSense detects vehicle movement$") {
            send(vehicleMotionandPositionSensor.vehicleMotionSensing("Vehicle is moving"))
        }
        Then(
            "^The Information Domain computer will notify the user that the camera is faulty, via DASy, Central Gateway unit and Vehicle control unit$"
        ) {
            eventually(informationDomainComputer.computerMessage("Please check camera"), informationDomainComputer.computerMessage("camera health is good"))
        }
        When("^The signal cameraSense detects moving object$") {
            send(cameraUnit.cameraSensing("Detecting moving Objects"))
        }
        Then(
            "^The Information Domain Computer will notify the user that the camera is working fine, via DASy, Central Gateway unit and Vehicle control unit$"
        ) {
            eventually(informationDomainComputer.computerMessage("camera health is good"), informationDomainComputer.computerMessage("Please check camera"))
        }
        When("^The signal cameraSense detects Rain or snow it send the signal to DASy$") {
            send(cameraUnit.detectRainSnow_Radar("Rain or snow detected"))
        }
        Then(
            "^DASy requests for both Mid Range and Millimeter Radar sensor and forwards the data to the Vehicle control unit via the Central Gateway unit$"
        ) {
            eventually(centralGatewayUnit.forwardRadarData("Radar reading"), centralGatewayUnit.forwardmilimeterRadarData("Millimeter Radar Reading"),
                cameraUnit.detectRainSnow_Radar("No rain or snow. Clear weather"))
        }
        When("^The signal cameraSense detects Clear weather$") {
            send(cameraUnit.detectRainSnow_Radar("No rain or snow. Clear weather"))
        }
        Then(
            "^DASy requests for only the data from Mid Range sensor and sends it to the Vehicle Control unit via the central gateway unit$"
        ) {
            eventually(centralGatewayUnit.forwardRadarData("Only mid range radar reading"), cameraUnit.detectRainSnow_Radar("Rain or snow detected"))
        }

    }
        fun send(event: Event) {
            runBlocking {
                testEventNode.send(event)
            }
        }

        fun receive(events: IEventSet) {
            return runBlocking {
                if (testEventNode.receive() != events) return@runBlocking Assert.fail()
            }
        }

        fun eventually(events: IEventSet, forbiddenEvents: IEventSet) {
            return runBlocking {
                do {
                    val receivedEvent = testEventNode.receive()
                    if (forbiddenEvents.contains(receivedEvent))
                        return@runBlocking Assert.fail()
                } while (receivedEvent != events)
            }
        }
    }
//added
//Function overloading done on eventually function so that 2 events can be tested till a forbidden event occurs
fun eventually(events: IEventSet, event: IEventSet, forbiddenEvents: IEventSet) {
    return runBlocking {
        do {
            val receivedEvent = testEventNode.receive()
            if (forbiddenEvents.contains(receivedEvent))
                return@runBlocking Assert.fail()
        } while (receivedEvent != events)
    }
}