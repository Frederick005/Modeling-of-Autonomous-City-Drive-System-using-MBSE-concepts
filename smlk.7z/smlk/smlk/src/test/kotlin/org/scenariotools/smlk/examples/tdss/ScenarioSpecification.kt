package org.scenariotools.smlk.examples.tdss

import org.scenariotools.smlk.*

//Mid range Radar sensor
class MidRangeSensor{
    fun detectObjects(arg1: String) = event{}
    var objectDetected= " "
    fun detectDistantObjects(request: String) = event(request){this.objectDetected = request}
    var reading= ""
    fun midRangeradarreading(request: String) = event(request){this.reading = request}
}
// Introducing new Sensor, Millimeter Radar Sensor as a solution to a threat case.
class MillimeterRadarSensor{
    var radarreading = " "
    fun millimeterRadarReading(request: String)= event(request){this.radarreading = request}
}

//Near range Camera Sensor
class NearRangeSensor{
    var objectDetected= " "
    fun detectSurroundingObject(request: String)=event(request){this.objectDetected = request}
}

class DasyUnit{
    var msgvalue = " "
    fun sendNotification(request: String)=event(request){this.msgvalue = request}
    //For Camera Fault detection threat case
    fun forwardCameraNotification(request: String)= event(request){this.msgcamera = request}
    var msgcamera= " "
    //For radar and rain threat case
    var msgcameraradar= " "
    fun recieveRadarNotification(request: String)= event(request){this.msgcameraradar = request}
    var radarInformation= ""
    fun sendRadarData(request: String)=event(request){this.radarInformation}
    var millimeterradarInformation= ""
    fun sendmillimeterRadarData(request: String)=event(request){this.millimeterradarInformation}
}

//The Multi-Purpose camera unit.
class CameraUnit{
    var detect_rain= " "
    var detectmotion= " "
    fun detectHeavyRain(request: String) = event(request){this.detect_rain= request}
    fun detectmovement(request: String)= event(request){this.detectmotion= request}
    var detect_object= ""
    fun cameraSensing(request: String)=event(request){this.detect_object = request}
    //for radar
    var detectSnowRain =""
    fun detectRainSnow_Radar(request: String)=event(request){this.detectSnowRain = request}
}
class VehicleMotionandPositionSensor
{
    var data = ""
    fun vehicleMotionSensing(request: String)=event(request){this.data = request}
    fun distanceRate()=event{}
}
class InformationDomainComputer
{
    var displayMessage = ""
    fun computerMessage(request: String) = event(request) { this.displayMessage = request }
}
class CentralGatewayUnit{
    var msgvalue = " "
    var msgcamera= " "
    fun forwardNotification(request: String)=event(request){this.msgvalue = request}
    fun forwardCameraNotification(request: String)= event(request){this.msgcamera = request}
    //For radar and rain threat case
    var radarInformation= ""
    fun forwardRadarData(request: String)=event(request){this.radarInformation}
    var milimeterradarInformation= ""
    fun forwardmilimeterRadarData(request: String)=event(request){this.milimeterradarInformation}
}

class VehicleControlUnit {
    var msgvalue = " "
    var msgcamera= " "
    fun forwardgatewaymessage(request: String)=event(request){this.msgvalue = request}
    fun forwardCameraNotification(request: String)= event(request){this.msgcamera = request}
}
class ESPUnit {
    var vehicle_speed = " "
    fun preventskidding()=event{}
    fun ManipulateSpeed(request: String) = event(request){this.vehicle_speed = request}
}
class BrakeSystem{
    fun firmbrake()=event{}
    fun slowbrake()=event{}
}

fun assumptionScenarios(midrangesensor: MidRangeSensor): List<suspend Scenario.() -> Unit> {
    val listOf = listOf(
        scenario {
            //while(true){
                //val event = waitFor(ALLEVENTS)
                //continoProva.writeValueToImplementation(event)
                //request(continoProva.getValuesFromImplementation())

           // }
        }
    )
    return listOf
}

fun guaranteeScenarios(midrangesensor: MidRangeSensor,
                       vehiclecontrolunit:VehicleControlUnit,
                        nearRangeSensor: NearRangeSensor,
                        dasyUnit: DasyUnit, centralGatewayUnit: CentralGatewayUnit,espUnit: ESPUnit,brakeSystem: BrakeSystem,
                       cameraUnit: CameraUnit,vehicleMotionandPositionSensor: VehicleMotionandPositionSensor,
                        informationDomainComputer: InformationDomainComputer,millimeterRadarSensor: MillimeterRadarSensor
                        ) = listOf(

    //Scenarios for Braking System Threat case
    scenario(midrangesensor.detectDistantObjects( "Detect Object")) {
        request(dasyUnit.sendNotification("Detect Object"))
        request(centralGatewayUnit.forwardNotification("Detect Object"))
    },
    scenario(nearRangeSensor.detectSurroundingObject( "Detect near range Object")) {
        request(dasyUnit.sendNotification("Detect near range Object"))
        request(centralGatewayUnit.forwardNotification("Detect near range Object"))
    },
    scenario(vehiclecontrolunit.forwardgatewaymessage( " Detect near range Object")){
            request(brakeSystem.firmbrake())
    },
    scenario(vehiclecontrolunit.forwardgatewaymessage( " Detect Object")) {
        request(brakeSystem.slowbrake())
    },

    // Scenarios for Anti-Skid Braking System Threat case
    // If camera Detects Heavy rain then it informs the Esp unit via the DASy, central gateway unit and vehicle control unit
    scenario(cameraUnit.detectHeavyRain("Heavy Rain")){
        request(dasyUnit.sendNotification("Heavy Rain"))
        request(centralGatewayUnit.forwardNotification("Heavy Rain"))
    },
    scenario(vehiclecontrolunit.forwardgatewaymessage("Heavy Rain")){
        request(espUnit.ManipulateSpeed("Prevent Skidding"))
    },


    // Scenarios for Camera Fault Detection Threat case
    // detecting non moving objects by camera
    scenario(cameraUnit.cameraSensing("Detecting non moving Objects")) {
        request(dasyUnit.forwardCameraNotification("Detecting non moving Objects"))
    },
    // detecting moving objects by camera
    scenario(cameraUnit.cameraSensing("Detecting moving Objects")) {
        request(dasyUnit.forwardCameraNotification("Detecting moving Objects"))
    },

    // detecting vehicle movement by the vehicle motion sensor
    scenario(vehicleMotionandPositionSensor.vehicleMotionSensing("Vehicle is moving")) {
        request(dasyUnit.forwardCameraNotification("Vehicle is moving"))
    },
    // detecting vehicle not moving by the vehicle motion sensor
    scenario(vehicleMotionandPositionSensor.vehicleMotionSensing("Vehicle is not moving")) {
        request(dasyUnit.forwardCameraNotification("Vehicle is not moving"))

    },
    scenario(dasyUnit.forwardCameraNotification("Detecting non moving Objects")){
        waitFor(dasyUnit.forwardCameraNotification("Vehicle is moving"))
        request(centralGatewayUnit.forwardCameraNotification("faulty camera"))

    },
    scenario(dasyUnit.forwardCameraNotification("Detecting moving Objects")){
        waitFor(dasyUnit.forwardCameraNotification("Vehicle is moving"))
        request(centralGatewayUnit.forwardCameraNotification("camera is good"))

    },
    scenario(centralGatewayUnit.forwardCameraNotification("faulty camera")){
        request(informationDomainComputer.computerMessage("Please check camera"))
    },
    scenario(centralGatewayUnit.forwardCameraNotification("camera is good")){
        request(informationDomainComputer.computerMessage("camera health is good"))
    },

    //Scenarios for Radar Threat case
    //In Case Rain or snow is detected by the Camera then the DASy system requestes for the data from both the Radar Sensor and Millimeter sensor
    scenario (cameraUnit.detectRainSnow_Radar("Rain or snow detected")) {
        request(dasyUnit.recieveRadarNotification("Rain or snow detected"))
    },
    scenario(dasyUnit.recieveRadarNotification("Rain or snow detected")) {
        request(millimeterRadarSensor.millimeterRadarReading("Millimeter Radar Reading"))
        request(midrangesensor.midRangeradarreading("Radar reading"))
    },
    scenario(dasyUnit.recieveRadarNotification("Rain or snow detected")){
        request(dasyUnit.sendRadarData("Radar reading"))
        request(dasyUnit.sendmillimeterRadarData("Millimeter Radar Reading"))
        request(centralGatewayUnit.forwardRadarData("Radar reading"))
        request(centralGatewayUnit.forwardmilimeterRadarData("Millimeter Radar Reading"))
    },
    //In case the camera detects clear weather then only the mid range radar data is used and forwarded to vehicle control unit
    scenario(cameraUnit.detectRainSnow_Radar("No rain or snow. Clear weather")) {
        request(dasyUnit.recieveRadarNotification("No rain or snow. Clear weather"))
    },
    scenario(dasyUnit.recieveRadarNotification("No rain or snow. Clear weather")) {
        request(midrangesensor.midRangeradarreading("Only mid range radar reading"))
    },
    scenario(dasyUnit.recieveRadarNotification("No rain or snow. Clear weather")) {
        request(dasyUnit.sendRadarData("Only mid range radar reading"))
        request(centralGatewayUnit.forwardRadarData("Only mid range radar reading"))
    }
)



fun createScenarioProgram(midrangesensor: MidRangeSensor,
                          nearRangeSensor: NearRangeSensor,
                          cameraUnit: CameraUnit,
                          dasyUnit: DasyUnit,
                          centralGatewayUnit: CentralGatewayUnit,
                          espUnit: ESPUnit,
                          brakeSystem: BrakeSystem,
                          vehiclecontrolunit: VehicleControlUnit,
                          vehicleMotionandPositionSensor: VehicleMotionandPositionSensor,
                          informationDomainComputer: InformationDomainComputer,
                          millimeterRadarSensor: MillimeterRadarSensor
) : ScenarioProgram {

    val scenarioProgram = ScenarioProgram(
        "Specification Model",
        isControlledObject = { o : Any -> o is VehicleControlUnit }, // ObjectEvent side effects of DeratingComponents, e.g. setCoolantTemperature(...), will only be executed by the DeratingScenarioProgram, and not the test program.
        eventNodeInputBufferSize = 25)


    scenarioProgram.addEnvironmentMessageType(
        midrangesensor::detectDistantObjects,
        nearRangeSensor::detectSurroundingObject,
        cameraUnit::detectHeavyRain,
        vehiclecontrolunit::forwardgatewaymessage,
        cameraUnit::detectmovement,
        cameraUnit::cameraSensing,
        vehicleMotionandPositionSensor::vehicleMotionSensing,
        cameraUnit::detectRainSnow_Radar,
        millimeterRadarSensor::millimeterRadarReading
    )

    scenarioProgram.activeGuaranteeScenarios.addAll(
        guaranteeScenarios(
            midrangesensor, vehiclecontrolunit,nearRangeSensor,dasyUnit,centralGatewayUnit,espUnit,brakeSystem,cameraUnit,vehicleMotionandPositionSensor, informationDomainComputer,
            millimeterRadarSensor
        )
    )

    return scenarioProgram
}
suspend fun main(args:Array<String>) {

}