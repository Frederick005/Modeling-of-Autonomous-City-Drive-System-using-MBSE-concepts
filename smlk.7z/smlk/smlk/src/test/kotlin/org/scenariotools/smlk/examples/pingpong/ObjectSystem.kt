package org.scenariotools.smlk.examples.pingpong

import org.scenariotools.smlk.event

//data class Environment(val name : String)
//data class TableSensor(val name : String)
//data class ArmA(val name : String)
//data class ArmB(val name : String)

abstract class NamedElement(val name : String){
    override fun toString(): String {
        return name
    }
}

object Env : NamedElement("Env") {
}

object PingMe : NamedElement("PingMe") {
    fun ping(x : Int) = event(x){}
}

object PongMe : NamedElement("PongMe")  {
    fun start() = event(){}
    fun pong(x : Int, y : Int) = event(x, y){}
}