package org.scenariotools.smlk.examples.tdss

import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.Assert
import org.junit.Rule
import org.junit.Test
import org.junit.rules.Timeout
import org.scenariotools.smlk.*


val midRangeSensor = MidRangeSensor()
val vehicleControlUnit = VehicleControlUnit()
val nearRangeSensor= NearRangeSensor()
val dasyUnit= DasyUnit()
val centralGatewayUnit= CentralGatewayUnit()
val espUnit= ESPUnit()
val brakeSystem= BrakeSystem()
val cameraUnit= CameraUnit()
val vehicleMotionandPositionSensor=VehicleMotionandPositionSensor()
val informationDomainComputer= InformationDomainComputer()
val millimeterRadarSensor = MillimeterRadarSensor()

var specificationModel = createScenarioProgram(midRangeSensor, nearRangeSensor, cameraUnit, dasyUnit,
    centralGatewayUnit, espUnit, brakeSystem, vehicleControlUnit, vehicleMotionandPositionSensor,
    informationDomainComputer, millimeterRadarSensor)
var testEventNode = EventNode()

fun connectSpecificationModel(){
    testEventNode = EventNode()
    specificationModel = createScenarioProgram(midRangeSensor, nearRangeSensor, cameraUnit, dasyUnit,
        centralGatewayUnit, espUnit, brakeSystem, vehicleControlUnit,vehicleMotionandPositionSensor, informationDomainComputer,
        millimeterRadarSensor)

    specificationModel.terminatingEvents.add(TestDoneEvent)
    specificationModel.eventNode.registerSender(testEventNode, specificationModel.environmentMessageTypes.symbolicEvents() union TestDoneEvent)
    val observedTesteeEvents = ALLEVENTS excluding specificationModel.environmentMessageTypes.symbolicEvents()
    testEventNode.registerSender(specificationModel.eventNode, observedTesteeEvents excluding TestDoneEvent)


    runBlocking(){
         GlobalScope.launch {
            specificationModel.run()
        }


    }
}

class TDSS {
    init {
        connectSpecificationModel()
    }

    // Test cases for Braking Threat Case
    @Test(timeout=1000)
    fun `check if DASy sends notification after mid-range sensor detects an object`(){
        send(midRangeSensor.detectDistantObjects("Detect Object"))
        receive(dasyUnit.sendNotification("Detect Object"))
    }

    @Test(timeout = 1000)
    fun `check if DASy sends notification after near-range sensor detects an object`(){
        send(nearRangeSensor.detectSurroundingObject("Detect near range Object"))
        receive(dasyUnit.sendNotification("Detect near range Object"))
    }

    @Test(timeout = 1000)
    fun `check if central gateway forwards notification for mid-range object`(){
        send(midRangeSensor.detectDistantObjects("Detect Object"))
        receive(dasyUnit.sendNotification("Detect Object"))
        receive(centralGatewayUnit.forwardNotification("Detect Object"))
    }

    @Test(timeout = 1000)
    fun `check if central gateway forwards notification for near-range object`(){
        send(nearRangeSensor.detectSurroundingObject("Detect near range Object"))
        receive(dasyUnit.sendNotification("Detect near range Object"))
        receive(centralGatewayUnit.forwardNotification("Detect near range Object"))
    }

    @Test(timeout = 1000)
    fun `check if brake is applied for near-range object`(){
        send(vehicleControlUnit.forwardgatewaymessage(" Detect near range Object"))
      receive(brakeSystem.firmbrake())
    }

    @Test(timeout = 1000)
    fun `check if brake is applied for mid-range object`(){
        send(vehicleControlUnit.forwardgatewaymessage(" Detect Object"))
        receive(brakeSystem.slowbrake())
    }

    // Test cases for Anti-Skidding Threat Case.
    @Test(timeout = 1000)
    fun `Esp unit prevents skidding`(){
        send(vehicleControlUnit.forwardgatewaymessage("Heavy Rain"))
        receive(espUnit.ManipulateSpeed("Prevent Skidding"))
    }
    @Test(timeout = 1000)
    fun `Check the message flow from camera unit to ESP Unit`(){
        send(cameraUnit.detectHeavyRain("Heavy Rain"))
        receive(dasyUnit.sendNotification("Heavy Rain"))
        receive(centralGatewayUnit.forwardNotification("Heavy Rain"))
        //receive(vehicleControlUnit.forwardgatewaymessage("Heavy Rain"))
    }

    // Test cases for Camera Fault Detection Threat Case
    @Test(timeout=1000)
    fun `check if DASy sends notification after camera sensor does not detect an object`(){
        send(cameraUnit.cameraSensing("Detecting non moving Objects"))
        send(vehicleMotionandPositionSensor.vehicleMotionSensing("Vehicle is moving"))
        eventually(informationDomainComputer.computerMessage("Please check camera"), (informationDomainComputer.computerMessage("camera health is good")))
    }
    @Test(timeout = 1000)
    fun `check if DASy sends notification after camera sensor detects a moving object`(){
        send(cameraUnit.cameraSensing("Detecting moving Objects"))
        send(vehicleMotionandPositionSensor.vehicleMotionSensing("Vehicle is moving"))
        eventually((informationDomainComputer.computerMessage("camera health is good")), informationDomainComputer.computerMessage("Please check camera"))
    }
    //Test cases for varying readings and using both radar and millimeter radar when raining or snowing
    @Test(timeout=1000)
    fun `check if data from both millimeter and mid-range radar system is sent by DASy if it rains or snows`(){
        send(cameraUnit.detectRainSnow_Radar("Rain or snow detected"))
        eventually((centralGatewayUnit.forwardRadarData("Radar reading")), centralGatewayUnit.forwardmilimeterRadarData("Millimeter Radar Reading"), cameraUnit.detectRainSnow_Radar("No rain or snow. Clear weather"))
    }
    @Test(timeout = 1000)
    fun `check if data from only Mid-range sensor is sent by DASy in case of normal weather`(){
        send(cameraUnit.detectRainSnow_Radar("No rain or snow. Clear weather"))
        eventually(centralGatewayUnit.forwardRadarData("Only mid range radar reading"), cameraUnit.detectRainSnow_Radar("Rain or snow detected"))
    }
}

fun send(event: Event){
    runBlocking {
       testEventNode.send(event)
    }
}

fun receive(events: IEventSet){
    return runBlocking {
        if (testEventNode.receive() != events) return@runBlocking Assert.fail()
    }
}

fun eventually(events: IEventSet, forbiddenEvents: IEventSet) {
    return runBlocking {
        do {
            val receivedEvent = testEventNode.receive()
            if (forbiddenEvents.contains(receivedEvent))
                return@runBlocking Assert.fail()
        } while (receivedEvent != events)
    }
}

//added
//Function overloading done on eventually function so that 2 events can be tested till a forbidden event occurs
fun eventually(events: IEventSet, event: IEventSet, forbiddenEvents: IEventSet) {
    return runBlocking {
        do {
            val receivedEvent = testEventNode.receive()
            if (forbiddenEvents.contains(receivedEvent))
                return@runBlocking Assert.fail()
        } while (receivedEvent != events)
    }
}