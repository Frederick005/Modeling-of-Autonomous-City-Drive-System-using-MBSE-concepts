public class MyStepdefsCameraFaultDetect {
    public MyStepdefsCameraFaultDetect() {
        Given("^init test setup$", () -> {
        });
        When("^The signal cameraSense detects no moving object$", () -> {
        });
        And("^Also the signal motionSense detects vehicle movement$", () -> {
        });
        Then("^The Information Domain computer will notify the user that the camera is faulty, via DASy, Central Gateway unit and Vehicle control unit$", () -> {
        });
        When("^The signal cameraSense detects moving object$", () -> {
        });
        Then("^The Information Domain Computer will notify the user that the camera is working fine, via DASy, Central Gateway unit and Vehicle control unit$", () -> {
        });
    }
}
