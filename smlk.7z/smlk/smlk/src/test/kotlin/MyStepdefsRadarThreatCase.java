public class MyStepdefsRadarThreatCase {
    public MyStepdefsRadarThreatCase() {
        Given("^init test setup$", () -> {
        });
        When("^The signal cameraSense detects Rain or snow it send the signal to DASy$", () -> {
        });
        Then("^DASy requests for both Mid Range and Millimeter Radar sensor and forwards the data to the Vehicle control unit via the Central Gateway unit$", () -> {
        });
        When("^The signal cameraSense detects Clear weather$", () -> {
        });
        Then("^DASy requests for only the data from Mid Range sensor and sends it to the Vehicle Control unit via the central gateway unit$", () -> {
        });
    }
}
