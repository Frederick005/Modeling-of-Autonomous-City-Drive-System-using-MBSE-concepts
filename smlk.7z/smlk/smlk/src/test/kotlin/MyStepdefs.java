public class MyStepdefs {
    public MyStepdefs() {
        Given("^init test setup$", () -> {
        });
        When("^The Camera unit detects Heavy rain$", () -> {
        });
        Then("^It sends notification to the ESP unit via DASy unit ,Central Gateway unit and vehicle control unit$", () -> {
        });
        When("^The ESP unit recieves notification from Camera unit$", () -> {
        });
        Then("^It manipulates the speed of the vehicle to prevent skidding$", () -> {
        });
    }
}
