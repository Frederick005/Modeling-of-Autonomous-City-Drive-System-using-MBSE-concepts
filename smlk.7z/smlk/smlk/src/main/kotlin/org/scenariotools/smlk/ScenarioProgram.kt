package org.scenariotools.smlk

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import mu.KotlinLogging
import kotlin.reflect.KFunction


private val logger = KotlinLogging.logger {}

open class AbstractScenarioSyncMessage()
data class TerminatingScenarioMessage(val sender: Scenario, val violationException : ViolationException? = null) : AbstractScenarioSyncMessage()
data class SuspendMessage(val sender: Scenario, val forbiddenEvents: IEventSet) : AbstractScenarioSyncMessage()

data class ScenarioSyncMessage(
    val sender: Scenario,
    val waitedForEvents: IEventSet,
    val committedEvents: IConcreteEventSet,
    val requestedEvents: IConcreteEventSet,
    val forbiddenEvents: IEventSet,
    val toggleMustProgressState : Boolean) : AbstractScenarioSyncMessage()

data class AddActiveScenarioMessage(val sender: Scenario, val scenarioMain: suspend Scenario.() -> Unit) : AbstractScenarioSyncMessage()
data class AddTriggeredScenarioMessage<R:Any, T>(val sender: Scenario, val initObjectEvent : ObjectEvent<R, T>, val scenarioMain: suspend Scenario.(ObjectEvent<R, T>) -> Unit) : AbstractScenarioSyncMessage()
fun scenario(scenarioMain: suspend Scenario.() -> Unit) = scenarioMain

fun <R:Any, T> scenario(symbolicObjectEvent: SymbolicObjectEvent<R, T>, triggeredScenario: suspend Scenario.(ObjectEvent<R, T>) -> Unit): suspend Scenario.() -> Unit = {
    while(true){
        waitFor(symbolicObjectEvent).launchScenario(triggeredScenario)
    }
}
fun <R:Any, T> scenario(objectEvent: ObjectEvent<R, T>, triggeredScenario: suspend Scenario.(ObjectEvent<R, T>) -> Unit): suspend Scenario.() -> Unit = {
    while(true){
        waitFor(objectEvent).launchScenario(triggeredScenario)
    }
}
fun scenario(initialingEvents : NonConcreteEventSet, triggeredScenario: suspend Scenario.(ObjectEvent<Any, *>) -> Unit): suspend Scenario.() -> Unit = {
    while(true){
        @Suppress("UNCHECKED_CAST")
        (waitFor(initialingEvents) as ObjectEvent<Any, *>).launchScenario(triggeredScenario)
    }
}

object RESUME


class ScenarioProgram(
    val name : String = "",
    val environmentMessageTypes : MutableSet<KFunction<ObjectEvent<*,*>>> = mutableSetOf(),
    val isControlledObject : (Any) -> Boolean = { _ : Any -> true },
    val terminatingEvents : MutableSet<IEventSet> = mutableSetOf(),
    val activeAssumptionScenarios : MutableSet<suspend Scenario.() -> Unit> = hashSetOf(),
    val activeGuaranteeScenarios : MutableSet<suspend Scenario.() -> Unit> = hashSetOf(),
    eventNodeInputBufferSize : Int = 25,
    val superStepTerminationEvent : Event? = null,
    var terminateUponAssumptionViolation : Boolean = true,
    var terminateUponGuaranteeViolation : Boolean = false
) {


    private val syncChannel: Channel<AbstractScenarioSyncMessage> = Channel()
    private val resumeChannel: Channel<Scenario> = Channel()
    private var numberOfScenariosAwaitedToReachSyncPoint = 0
    private val activeScenariosToLastScenarioSychMessage: MutableMap<Scenario, ScenarioSyncMessage> = mutableMapOf()
    private val suspendedScenarioToForbiddenEvents: MutableMap<Scenario, IEventSet> = mutableMapOf()
    private val scenariosInMustProgressSection : MutableSet<Scenario> = hashSetOf()

    private var terminatingEventOccurred = false

    var terminated : Boolean = false

    val guaranteeViolationExceptions = mutableListOf<ViolationException>()
    val assumptionViolationExceptions = mutableListOf<ViolationException>()

    var inActiveSuperStep = true

    private var canMakeNextStep : Boolean = true

    fun canMakeNextStep() = canMakeNextStep

    fun init() {
        // start active scenarios
        for (activeScenario in activeAssumptionScenarios){
            startNewScenario(ScenarioKind.ASSUMPTION, activeScenario)
        }
        for (activeScenario in activeGuaranteeScenarios){
            startNewScenario(ScenarioKind.GUARANTEE, activeScenario)
        }
    }

    /**
     * Main event selection procedure:
     *
     * 1. Receive messages from all (non-suspended) scenarios
     *    if there are no scenarios in a must-progress state and a terminating event has occurred, then it's time to terminate.
     * 2. Calculate selectable events
     * 3. Select one of these events
     * 4. Invoke its side effects (i.e. "execute event")
     * 5. Communicate the executed event via output channels to connected event nodes that registered to receive this event
     * 6. Notify all active scenarios that committed this event, requested this event, or waited-for this event
     *
     * Returns an event if one was executed in this step. Returns null if no next step is possible
     */
    suspend fun makeStep() : Event?{

        assert(canMakeNextStep){"this method shall not be called when no next step is possible"}

        receiveSynchMessagesFromScenarios()

        if(scenariosInMustProgressSection.isEmpty() && terminatingEventOccurred){
            terminateScenarioProgram()
            return null
        }

        val selectableEvents = calculateSelectableEvents()
        val selectedEvent = selectEvent(selectableEvents)

        if (selectedEvent != null) {
            executeEvent(selectedEvent)
            if (!terminatingEventOccurred)
                terminatingEvents.let {terminatingEventOccurred = it.contains(selectedEvent)}
            eventNode.send(selectedEvent)
            notifyActiveScenariosAfterEventSelection(selectedEvent)
            return selectedEvent
        } else if(!suspendedScenarioToForbiddenEvents.isEmpty()) {
            tryToResumeSuspendedScenarios()
            return makeStep()
        } else{
            terminateScenarioProgram() // no event to select, not locally nor through connected event nodes: nothing more to do!
            return null
        }
    }


    /**
     * Runs the scenario program.
     */
    suspend fun run() {
        init()

        while(canMakeNextStep){
            makeStep()
        }

    }

    private suspend fun terminateScenarioProgram() {
        canMakeNextStep = false
        notifyActiveScenariosAfterEventSelection(TerminatedScenarioProgramEvent)
        receiveSynchMessagesFromScenarios() // allow scenarios to do one last step, especially raise last violations upon termination.
        eventNode.terminate()
        logger.debug { "Scenario program $name terminating. " +
                "Violation occurred: ${violationOccurred()} " +
                "Guarantee scenarios left in must-progress-sections: ${guaranteeScenariosInMustProgressSection()} " +
                "Assumption scenarios left in must-progress-sections: ${assumptionScenariosInMustProgressSection()} " }
        terminated = true
    }


    //=====================================================================================
    // Starting scenarios
    //=====================================================================================

    private fun <R:Any, T>Scenario.runTriggeredScenario(initObjectEvent : ObjectEvent<R, T>, scenarioMain : suspend Scenario.(ObjectEvent<R, T>) -> Unit) = coroutineScope.launch {
        scenarioMain(initObjectEvent)
        terminate()
    }

    private fun Scenario.runTriggeredScenario(scenarioMain : suspend Scenario.() -> Unit) = coroutineScope.launch {
        scenarioMain()
        terminate()
    }

    private fun startNewScenario(scenarioKind: ScenarioKind, scenarioMain : suspend Scenario.() -> Unit){
        Scenario(syncChannel, resumeChannel, GlobalScope, scenarioKind).runTriggeredScenario(scenarioMain)
        numberOfScenariosAwaitedToReachSyncPoint++
    }

    private fun <R:Any, T>startNewTriggeredScenario(addTriggeredScenarioMessage : AddTriggeredScenarioMessage<R,T>){
        Scenario(syncChannel, resumeChannel, GlobalScope, addTriggeredScenarioMessage.sender.scenarioKind).runTriggeredScenario(addTriggeredScenarioMessage.initObjectEvent, addTriggeredScenarioMessage.scenarioMain)
        numberOfScenariosAwaitedToReachSyncPoint++
    }


    //=====================================================================================
    // Main event loop functions:
    //=====================================================================================


    /**
     * Step 1 in event selection procedure: receive synch messages from scenarios
     */
    private suspend fun receiveSynchMessagesFromScenarios() {
        while (numberOfScenariosAwaitedToReachSyncPoint > 0) {
            val abstractScenarioMessage = syncChannel.receive()
            when (abstractScenarioMessage) {
                is ScenarioSyncMessage -> {
                    activeScenariosToLastScenarioSychMessage.put(
                        abstractScenarioMessage.sender,
                        abstractScenarioMessage
                    )
                    if(abstractScenarioMessage.toggleMustProgressState) {
                        if (scenariosInMustProgressSection.contains(abstractScenarioMessage.sender)) {
                            scenariosInMustProgressSection.remove(abstractScenarioMessage.sender)
                        } else {
                            scenariosInMustProgressSection.add(abstractScenarioMessage.sender)
                        }
                    }
                    numberOfScenariosAwaitedToReachSyncPoint--
                }
                is SuspendMessage -> {
                    suspendedScenarioToForbiddenEvents.put(
                        abstractScenarioMessage.sender,
                        abstractScenarioMessage.forbiddenEvents
                    )
                    numberOfScenariosAwaitedToReachSyncPoint--
                }
                is TerminatingScenarioMessage -> {
                    if (suspendedScenarioToForbiddenEvents.containsKey(abstractScenarioMessage.sender))
                        suspendedScenarioToForbiddenEvents.remove(abstractScenarioMessage.sender)
                    else {
                        activeScenariosToLastScenarioSychMessage.remove(abstractScenarioMessage.sender)
                        numberOfScenariosAwaitedToReachSyncPoint--
                        abstractScenarioMessage.violationException?.let{
                            recordViolation(it, abstractScenarioMessage.sender.scenarioKind)
                            logger.error { name + ": " + abstractScenarioMessage.violationException }
                        }
                    }
                    scenariosInMustProgressSection.remove(abstractScenarioMessage.sender)
                }
                is AddActiveScenarioMessage ->
                    startNewScenario(
                        abstractScenarioMessage.sender.scenarioKind,
                        abstractScenarioMessage.scenarioMain)
                is AddTriggeredScenarioMessage<*, *> ->
                    startNewTriggeredScenario(abstractScenarioMessage)
            }
        }
    }


    /**
     * Step 2 in event selection procedure: calculate selectable events
     */
    private suspend fun calculateSelectableEvents(): IConcreteEventSet {

        val allAssumptionForbiddenEvents = MutableNonConcreteEventSet()
        val allGuaranteeForbiddenEvents = MutableNonConcreteEventSet()

        val allAssumptionCommittedEvents = MutableConcreteEventSet()
        val allGuaranteeCommittedEvents = MutableConcreteEventSet()

        val allAssumptionRequestedEvents = MutableConcreteEventSet()
        val allGuaranteeRequestedEvents = MutableConcreteEventSet()


        for (scenarioToEventsMapEntry in activeScenariosToLastScenarioSychMessage){
            if (scenarioToEventsMapEntry.key.scenarioKind == ScenarioKind.ASSUMPTION){
                allAssumptionForbiddenEvents.addEvents(scenarioToEventsMapEntry.value.forbiddenEvents)
                allAssumptionCommittedEvents.addEvents(scenarioToEventsMapEntry.value.committedEvents)
                allAssumptionRequestedEvents.addEvents(scenarioToEventsMapEntry.value.requestedEvents)
            } else {
                allGuaranteeForbiddenEvents.addEvents(scenarioToEventsMapEntry.value.forbiddenEvents)
                allGuaranteeCommittedEvents.addEvents(scenarioToEventsMapEntry.value.committedEvents)
                allGuaranteeRequestedEvents.addEvents(scenarioToEventsMapEntry.value.requestedEvents)
            }
        }

        val ENV : (Event) -> Boolean = { !allAssumptionForbiddenEvents.contains(it) && !isSystemEvent(it) }
        val SYS : (Event) -> Boolean = { !allGuaranteeForbiddenEvents.contains(it) && isSystemEvent(it) }

        if (!allGuaranteeCommittedEvents.isEmpty()){
            val allSelectableEvents = allGuaranteeCommittedEvents.filter(SYS)
            if (allSelectableEvents.isEmpty()) recordViolation("All committed system events are forbidden by guarantee scenarios.", ScenarioKind.GUARANTEE)
            else return ConcreteEventSet(allSelectableEvents.toSet())
        }

        if (!allAssumptionCommittedEvents.isEmpty()){
            val allSelectableEvents = allAssumptionCommittedEvents.filter(ENV)
            if (allSelectableEvents.isEmpty()) recordViolation("All committed environment events are forbidden by assumption scenarios.", ScenarioKind.ASSUMPTION)
            else return ConcreteEventSet(allSelectableEvents.toSet())
        }

        val allGuaranteeRequestedNonForbiddenSystemEvents = allGuaranteeRequestedEvents.filter(SYS)

        if (!allGuaranteeRequestedNonForbiddenSystemEvents.isEmpty())
            return ConcreteEventSet(allGuaranteeRequestedNonForbiddenSystemEvents.toSet())
        else if (!allGuaranteeRequestedEvents.isEmpty())
            logger.debug {"$name -- There are requested system events, but all are forbidden by guarantee scenarios: $allGuaranteeRequestedEvents. Commencing to select an environment event next..."}

        if (superStepTerminationEvent != null
                && inActiveSuperStep){
            inActiveSuperStep = false
            return superStepTerminationEvent
        }

        inActiveSuperStep = true

        // if there are connected scenarioPrograms sending us input, wait for first process the events from the input channel
        if (!eventNode.inputChannelIsEmpty()) eventNode.receive().let {
            if (eventNode.inputChannelIsFull())
                logger.info { "$name: Input channel with buffer size ${eventNode.inputChannelBufferSize} is full!" }
            logger.debug{"$name: Early processing of input channel event. Received: $it"}
            return it
        }


        val allAssumptionRequestedNonForbiddenEnvironmentEvents = allAssumptionRequestedEvents.filter(ENV)

        if (!allAssumptionRequestedNonForbiddenEnvironmentEvents.isEmpty())
            return ConcreteEventSet(allAssumptionRequestedNonForbiddenEnvironmentEvents.toSet())


        // if no local event can be selected, but there are connected scenarioPrograms sending us input, wait for the next event from the input channel
        if(eventNode.sendersConnected())
            eventNode.receive().let {
            logger.debug{"$name: LATE waiting for input channel event. Received: $it"}
            return it
        }

        if (!allAssumptionRequestedEvents.isEmpty())
            recordViolation("There are request environment events, but all are forbidden by assumption scenarios: $allAssumptionRequestedEvents", ScenarioKind.ASSUMPTION)
        if (!allGuaranteeRequestedEvents.isEmpty())
            recordViolation("There are requested system events, but all are forbidden by guarantee scenarios: $allGuaranteeRequestedEvents.", ScenarioKind.GUARANTEE)

        logger.debug {"$name -- No next event to select."}

        return ConcreteEventSet()
    }

    private fun MutableNonConcreteEventSet.addEvents(events : IEventSet) {
        if (!events.isNOEVENTS()) this.add(events)
    }

    private fun HashSet<Event>.addEvents(events : IConcreteEventSet) {
        if (!events.isNOEVENTS()) this.addAll(events)
    }

    //TODO: replace by recursive isEmpty() implementation for all IEventSet implementations.
    private fun IEventSet.isNOEVENTS() = (this.isEmpty() || this == NOEVENTS || this is Collection<*> && this.size == 1 && this.iterator().next() == NOEVENTS)

    fun isSystemEvent(e : Event) = !(e is ObjectEvent<*,*>) || !(environmentMessageTypes.containsKFunction(e.type))


    /**
     * Step 3 in event selection procedure: select one selectable events
     */
    private fun selectEvent(selectableEvents: IConcreteEventSet): Event? =
        // TODO Make extensible to plug in different event selection strategies
        if (!selectableEvents.isEmpty())
            selectableEvents.first()
        else
            null

    /**
     * Step 4 in event selection procedure: Invoke its side effects (i.e. "execute event")
     */
    private fun executeEvent(selectedEvent: Event) {
        logger.debug {"########## $name -- executing event: $selectedEvent" }

        if (selectedEvent is ObjectEvent<*,*>
            && isControlledObject(selectedEvent.receiver)){
            selectedEvent.callFunction()
        }

    }

    /**
     * Step 6 in event selection procedure (after event selection and execution): notify all active scenarios that committed, requested, or waited-for this event
     */
    private suspend fun notifyActiveScenariosAfterEventSelection(selectedEvent: Event) {
        val scenarioToEventsMapEntryIterator = activeScenariosToLastScenarioSychMessage.iterator()

        while (scenarioToEventsMapEntryIterator.hasNext()) {
            val scenarioToEventsMapEntry = scenarioToEventsMapEntryIterator.next()
            if (scenarioToEventsMapEntry.value.waitedForEvents.contains(selectedEvent)
                || scenarioToEventsMapEntry.value.committedEvents.contains(selectedEvent)
                || scenarioToEventsMapEntry.value.requestedEvents.contains(selectedEvent)
                || scenarioToEventsMapEntry.value.forbiddenEvents.contains(selectedEvent)
                ) {
                scenarioToEventsMapEntry.key.notifyOfEventChannel.send(selectedEvent)
                scenarioToEventsMapEntryIterator.remove()
                numberOfScenariosAwaitedToReachSyncPoint++
            }
        }
    }


    /**
     * Called after each event-selection-and-execution step, try to resume suspended scenarios.
     */
    private suspend fun tryToResumeSuspendedScenarios() {
        while (!suspendedScenarioToForbiddenEvents.isEmpty() && !resumeChannel.isEmpty){
            val resumedScenario = resumeChannel.receive()
            numberOfScenariosAwaitedToReachSyncPoint++
            suspendedScenarioToForbiddenEvents.remove(resumedScenario)
        }
    }

    //=====================================================================================
    // Recording and throwing violations
    //=====================================================================================

    private fun recordViolation(message : String, scenarioKind: ScenarioKind) = recordViolation(ViolationException(message), scenarioKind)
    private fun recordViolation(violationException: ViolationException, scenarioKind: ScenarioKind) {
        logger.error { violationException.message }
        when (scenarioKind){
            ScenarioKind.GUARANTEE -> {
                guaranteeViolationExceptions.add(violationException)
                if (terminateUponGuaranteeViolation) throw CompositeViolationException()
            }
            ScenarioKind.ASSUMPTION -> {
                assumptionViolationExceptions.add(violationException)
                if (terminateUponAssumptionViolation) throw CompositeViolationException()
            }
        }
    }

    fun assumptionScenariosInMustProgressSection() = scenariosInMustProgressSection.filter { s -> s.scenarioKind == ScenarioKind.ASSUMPTION }
    fun guaranteeScenariosInMustProgressSection() = scenariosInMustProgressSection.filter { s -> s.scenarioKind == ScenarioKind.GUARANTEE }

    fun assumptionViolationOccurred() = !assumptionViolationExceptions.isEmpty() || (terminated && !assumptionScenariosInMustProgressSection().isEmpty())
    fun guaranteeViolationOccurred() = !guaranteeViolationExceptions.isEmpty() || (terminated && !guaranteeScenariosInMustProgressSection().isEmpty())
    fun violationOccurred() = assumptionViolationOccurred() || guaranteeViolationOccurred()
    fun specificationViolated() = !assumptionViolationOccurred() && guaranteeViolationOccurred()

    inner class CompositeViolationException() : RuntimeException() {
        fun getExceptions() = listOf(
            assumptionViolationExceptions,
            generateAssumptionMustProgressViolations(),
            guaranteeViolationExceptions,
            generateGuaranteeMustProgressViolations()).flatten()
        private fun generateAssumptionMustProgressViolations() = assumptionScenariosInMustProgressSection().map {
                e -> ViolationException("Assumption scenario name=\"${e.name}\" did not progress in a must-progress state.")}.toList()
        private fun generateGuaranteeMustProgressViolations() = guaranteeScenariosInMustProgressSection().map {
                e -> ViolationException("Guarantee scenario name=\"${e.name}\" did not progress in a must-progress state.")}.toList()

        override val message: String?
            get() = when (violationOccurred()){
                true -> "\n" + assumptionViolationExceptions.joinToString(separator = "\n ") { it -> "ASSUMPTION VIOLATION: ${it.message}" } +
                        "\n ----- \n" + generateAssumptionMustProgressViolations().joinToString(separator = "\n ") { it -> "ASSUMPTION VIOLATION: ${it.message}" } +
                        "\n ----- \n" + guaranteeViolationExceptions.joinToString(separator = "\n ") { it -> "GUARANTEE VIOLATION: ${it.message}" } +
                        "\n ----- \n" + generateGuaranteeMustProgressViolations().joinToString(separator = "\n ") { it -> "ASSUMPTION VIOLATION: ${it.message}" }

                false -> ""
            }
    }

    //=====================================================================================
    // Functions for adding scenarios to the scenario program before running it. (To be done before running the scenario program)
    //=====================================================================================

    /**
     * Adds environment message types (KFunctions). To be done before running the scenario program.
     * Any event typed with a KFunction added here is called an "environment event", otherwise "system event".
     * - Only environment events can be committed/requested in assumption scenarios.
     * - Only system events can be committed/requested in guarantee scenarios.
     * - System events are selected with priority over environment events:
     *   1. Comitted environment events are selected only when there are no committed system events
     *   2. Non-committed environment events are selected only when there are no system events committed or requested.
     */
    fun addEnvironmentMessageType(vararg kFunctions : KFunction<ObjectEvent<*,*>>){
        environmentMessageTypes.addAll(kFunctions)
    }

    //=============================================================================
    // Code for communicating with the scenario program / between scenario programs
    //=============================================================================

    val eventNode = EventNode(eventNodeInputBufferSize)

}

data class ViolationException(override val message : String = "", val scenarioName : String = "") : RuntimeException(message)

object TerminatedScenarioProgramEvent: Event() {
    override fun toString() = "TerminatedScenarioProgramEvent"
}