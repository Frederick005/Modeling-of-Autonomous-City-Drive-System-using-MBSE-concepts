package org.scenariotools.smlk

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.Channel

enum class ScenarioKind {
    ASSUMPTION, GUARANTEE
}

class Scenario(
    private val syncChannel: Channel<AbstractScenarioSyncMessage>,
    private val resumeChannel: Channel<Scenario>,
    val coroutineScope: CoroutineScope,
    val scenarioKind: ScenarioKind) {

    val notifyOfEventChannel : Channel<Event> = Channel()

    var name = ""

    private var toggleMustProgress = false

    private var suspended = false

    suspend fun terminate(cause : String? = null, violationException: ViolationException? = null){
        if (suspended)
            resume()
        syncChannel.send(TerminatingScenarioMessage(this, violationException))
        throw CancellationException(cause)
    }

    suspend fun resume() {
        assert(!suspended, {"Scenario is not suspended, thus cannot be resumed."})
        resumeChannel.send(this)
        suspended = false
    }

    suspend fun suspend(forbiddenEvents: IEventSet = NOEVENTS) {
        syncChannel.send(SuspendMessage(this, forbiddenEvents))
    }

    suspend fun sync(
        waitedForEvents : IEventSet = NOEVENTS,
        committedEvents: IConcreteEventSet = NOEVENTS,
        requestedEvents: IConcreteEventSet = NOEVENTS,
        forbiddenEvents : IEventSet = NOEVENTS) : Event {
        val forbiddenEventsExcludingRequestedOrWaitedForEvents =
            forbiddenEvents excluding (waitedForEvents union requestedEvents)
        val syncMessage = ScenarioSyncMessage(this, waitedForEvents, committedEvents, requestedEvents, forbiddenEventsExcludingRequestedOrWaitedForEvents, toggleMustProgress)
        syncChannel.send(syncMessage)
        toggleMustProgress = false
        val receivedEvent = notifyOfEventChannel.receive()
        if(forbiddenEventsExcludingRequestedOrWaitedForEvents.contains(receivedEvent))
            violation("Event $receivedEvent is forbidden by scenario")
        if ((interruptingEvents).contains(receivedEvent)){
            terminate()
        }
        return receivedEvent
    }

    val interruptingEvents = MutableNonConcreteEventSet()
    val forbiddenEvents = MutableNonConcreteEventSet()

    suspend fun waitFor(waitedForEvents : IEventSet, additionalEventsForbiddenAtThisSyncPoint : IEventSet = NOEVENTS) : Event {
        return sync(waitedForEvents = MutableNonConcreteEventSet(*interruptingEvents.toTypedArray(), waitedForEvents), forbiddenEvents = MutableNonConcreteEventSet(*(forbiddenEvents.toTypedArray()), additionalEventsForbiddenAtThisSyncPoint))
    }

    suspend fun commit(committedEvents: IConcreteEventSet, additionalEventsForbiddenAtThisSyncPoint : IEventSet = NOEVENTS) : Event {
        return sync(waitedForEvents = interruptingEvents, committedEvents = committedEvents, forbiddenEvents = forbiddenEvents union additionalEventsForbiddenAtThisSyncPoint)
    }

    suspend fun request(requestEvents: IConcreteEventSet, additionalEventsForbiddenAtThisSyncPoint : IEventSet = NOEVENTS) : Event {
        return sync(waitedForEvents = interruptingEvents, requestedEvents = requestEvents, forbiddenEvents = forbiddenEvents union additionalEventsForbiddenAtThisSyncPoint)
    }


    @Suppress("UNCHECKED_CAST")
    suspend fun <R:Any,T> waitFor(objectEvent: ObjectEvent<R,T>, additionalEventsForbiddenAtThisSyncPoint : IEventSet = NOEVENTS) : ObjectEvent<R,T> = waitFor(objectEvent as IEventSet, additionalEventsForbiddenAtThisSyncPoint) as ObjectEvent<R,T>
    @Suppress("UNCHECKED_CAST")
    suspend fun <R:Any,T> waitFor(symbolicObjectEvent: SymbolicObjectEvent<R,T>, additionalEventsForbiddenAtThisSyncPoint : IEventSet = NOEVENTS) : ObjectEvent<R,T> = waitFor(symbolicObjectEvent as IEventSet, additionalEventsForbiddenAtThisSyncPoint) as ObjectEvent<R,T>
    @Suppress("UNCHECKED_CAST")
    suspend fun <R:Any,T> commit(objectEvent: ObjectEvent<R,T>, additionalEventsForbiddenAtThisSyncPoint : IEventSet = NOEVENTS) : ObjectEvent<R,T> = commit(objectEvent as IConcreteEventSet, additionalEventsForbiddenAtThisSyncPoint) as ObjectEvent<R,T>
    @Suppress("UNCHECKED_CAST")
    suspend fun <R:Any,T> request(objectEvent: ObjectEvent<R,T>, additionalEventsForbiddenAtThisSyncPoint : IEventSet = NOEVENTS) : ObjectEvent<R,T> = request(objectEvent as IConcreteEventSet, additionalEventsForbiddenAtThisSyncPoint) as ObjectEvent<R,T>

    suspend fun violation(msg:String="") = terminate(msg, ViolationException(msg, name))

    suspend fun launchScenario(scenarioMain: suspend Scenario.() -> Unit) = syncChannel.send(AddActiveScenarioMessage(this, scenarioMain))
    suspend fun <R:Any,T> ObjectEvent<R,T>.launchScenario(scenarioMain: suspend Scenario.(ObjectEvent<R,T>) -> Unit) = syncChannel.send(AddTriggeredScenarioMessage(this@Scenario, this, scenarioMain))

    suspend fun mustProgress(mustProgressFragment : suspend Scenario.() -> Unit) {
        toggleMustProgress = !toggleMustProgress // toggleMustProgress = true unless a mustProgress {...} section is followed immediately by another.
        mustProgressFragment.invoke(this)
        toggleMustProgress = true
    }

    suspend fun <R:Any,T> mustOccur(symbolicObjectEvent: SymbolicObjectEvent<R,T>, additionalEventsForbiddenAtThisSyncPoint : IEventSet = NOEVENTS) : ObjectEvent<R,T> {
        toggleMustProgress = !toggleMustProgress
        val event = waitFor(symbolicObjectEvent, additionalEventsForbiddenAtThisSyncPoint)
        toggleMustProgress = true
        return event
    }

    suspend fun <R:Any,T> mustOccur(objectEvent: ObjectEvent<R,T>, additionalEventsForbiddenAtThisSyncPoint : IEventSet = NOEVENTS) : ObjectEvent<R,T> {
        toggleMustProgress = !toggleMustProgress
        val event = waitFor(objectEvent, additionalEventsForbiddenAtThisSyncPoint)
        toggleMustProgress = true
        return event
    }

    suspend fun mustOccur(condition : () -> Boolean) {
        toggleMustProgress = !toggleMustProgress
        waitFor(condition)
        toggleMustProgress = true
    }

    suspend infix fun IEventSet.interrupts( interruptableFragment : suspend Scenario.() -> Unit) {
        this@Scenario.interruptingEvents.add(this)
        interruptableFragment.invoke(this@Scenario)
        this@Scenario.interruptingEvents.remove(this)
    }
    suspend infix fun IEventSet.forbiddenIn( interruptableFragment : suspend Scenario.() -> Unit) {
        this@Scenario.forbiddenEvents.add(this)
        interruptableFragment.invoke(this@Scenario)
        this@Scenario.forbiddenEvents.remove(this)
    }

    suspend infix fun (suspend Scenario.() -> Unit).before(forbiddenEvents : IEventSet) {
        this@Scenario.forbiddenEvents.add(forbiddenEvents)
        this.invoke(this@Scenario)
        this@Scenario.forbiddenEvents.remove(forbiddenEvents)
    }

    suspend fun waitFor (condition : () -> Boolean) {
        while(!condition.invoke()) {
            waitFor(ALLEVENTS)
        }
    }

    override fun toString() : String {
        if (name != "") return name
        else return super.toString()
    }

}

