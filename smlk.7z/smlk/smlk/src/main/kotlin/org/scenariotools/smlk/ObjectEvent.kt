package org.scenariotools.smlk

import kotlin.reflect.KFunction

interface IFunctionCallEvent{
    fun callFunction()
}

interface IFunctionCallWithResultEvent : IFunctionCallEvent {
    fun result() : Any?
}

class ObjectEvent<R:Any,T>(val receiver:R, val type:KFunction<ObjectEvent<R,T>>, vararg val parameters : Any, val sideEffect: () -> T) : Event(),
    IFunctionCallWithResultEvent {

    override fun hashCode() =
            (31 * receiver.hashCode()
                    + 31 * type.hashCode()
                    + parameters.sumBy { 31 * it.hashCode() })

    override fun equals(other : Any?): Boolean {
        if (other is ObjectEvent<*,*>)
            return other.signatureEquals(receiver, type)
                    && parameterValuesEqual(other)
        else
            return false
    }


    override fun toString(): String {
        fun functionCallResultString() = if (functionCallResult != null && !(functionCallResult is Unit)) " = " + functionCallResult.toString() else ""
        val paramString = parameters.joinToString(separator = ", ", prefix = "(", postfix = ")")
        return "$receiver.${type.name}$paramString" + functionCallResultString()
    }

    private var functionCallResult : T? = null

    var invoked = false

    override fun callFunction() {
        if (!invoked){
            try{
                functionCallResult = sideEffect.invoke()
            }catch(e: Exception){
                println("Failed to invoke side effect on object $receiver associated scenario message event ${this.toString()}, $e")
            }
            invoked = true
        }
    }

    override fun result() = functionCallResult

}


fun ObjectEvent<*,*>.parameterValuesEqual(otherObjectEvent : ObjectEvent<*,*>) : Boolean{
    if (parameters.size != otherObjectEvent.parameters.size)
        assert(false, {"There must not be different numbers of scenario"})
    for (i in 0..parameters.size-1)
        if (parameters.get(i) != otherObjectEvent.parameters.get(i)) return false
    return true
}

fun ObjectEvent<*,*>.signatureEquals(receiver: Any, messageType : Any) : Boolean {
    if (!this.type.kFunctionEquals(messageType))
        return false
    if (receiver != this.receiver)
        return false
    return true
}
