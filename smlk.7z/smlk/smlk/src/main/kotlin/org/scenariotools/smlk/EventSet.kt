package org.scenariotools.smlk

import java.lang.UnsupportedOperationException
import kotlin.collections.HashSet

interface IEventSet{
    fun contains (element : Event) : Boolean
    fun isEmpty() : Boolean
}

interface IConcreteEventSet : IEventSet, Collection<Event> {}

open class MutableNonConcreteEventSet(vararg events : IEventSet) : IEventSet, HashSet<IEventSet>(events.asList()){

    override fun contains(element: Event): Boolean {
        for (eventSet in this) {
            if (eventSet.contains(element)) return true
        }
        return false
    }
}

open class NonConcreteEventSet(vararg events : IEventSet) : IEventSet, Set<IEventSet> by events.toSet(){
    override fun contains(element: Event): Boolean {
        for (eventSet in this) {
            if (eventSet.contains(element)) return true
        }


        return false
    }
}

open class NonConcreteEventSetExcludingEvents(val baseEventSet : IEventSet, val excludingEventSet : IEventSet) : IEventSet {
    override fun contains(element: Event) =
        !excludingEventSet.contains(element) && baseEventSet.contains(element)
    override fun isEmpty() = baseEventSet.isEmpty()
}

open class ConcreteEventSet(c: Set<Event>) : Set<Event> by c,
    IConcreteEventSet {
    constructor(vararg event : Event) : this(event.toSet())
}


open class MutableConcreteEventSet : HashSet<Event>,
    IConcreteEventSet {
    constructor() : super()
    constructor(c: MutableCollection<Event>) : super(c)
    constructor(vararg event : Event) : super(event.toMutableSet())
}

open class ComplementEventSet(val events : IEventSet) : IEventSet{
    override fun contains(element: Event): Boolean {
        return !events.contains(element)
    }
    override fun isEmpty() = false
}

object ALLEVENTS : IEventSet {
    override fun contains(element: Event) = true

    override fun isEmpty() = false
}


object NOEVENTS : IConcreteEventSet {
    override val size: Int
        get() = 0

    override fun containsAll(elements: Collection<Event>) = false

    override fun isEmpty() = true

    override fun iterator(): Iterator<Event> =
        EmptyEventIterator()

    override fun contains(element: Event) = false

    private class EmptyEventIterator() : Iterator<Event>{

        override fun hasNext() = false

        override fun next(): Event {
            throw UnsupportedOperationException()
        }

    }

}

infix fun IEventSet.union(events : IEventSet) = NonConcreteEventSet(this, events)
infix fun IEventSet.excluding(events : IEventSet) = NonConcreteEventSetExcludingEvents(this, events)